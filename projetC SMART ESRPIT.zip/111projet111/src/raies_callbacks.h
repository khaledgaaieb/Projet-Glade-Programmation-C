#include <gtk/gtk.h>


void
on_act_rec_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_mod_rec_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_rechch_rec_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_ajj_rec_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_supp_rec_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_rec_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_ajout_recc_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_modif_recc_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_annn_mod_rec_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_ann_supp_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_con_supp_rec_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton2_rec_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_rec_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton1_rec_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_rec_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_annn_aj_rec_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_stat_recc_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_inscripp_rec_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_auth_rec_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_inscri_rec_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_ann_inrec_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_go_aff_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_serv_pluss_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_ret_acui_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_go_aff1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_serv_pluss1_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_ret_acui1_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_homme_rec_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_decc_rec_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_serrplusrecl1_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_deccc2_rec_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_home2_rec_clicked                   (GtkButton       *button,
                                        gpointer         user_data);
