#include<gtk/gtk.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>



typedef struct 
{
int id;
char nom[30];
char prenom[30];
char cin[30];
char type[30];
char service[20];
char date_rec[30];
char text[255];
}reclamation;

