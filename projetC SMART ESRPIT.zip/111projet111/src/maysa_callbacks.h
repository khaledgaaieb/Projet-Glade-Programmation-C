#include <gtk/gtk.h>


void
on_button1_mm_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_supp_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_aj_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_aff_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_mod_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton2_sal_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_rm_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton3_d_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_suc_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton1_pd_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button7_val_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button9_mod_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button11_supprimer_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_buton_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

gboolean
on_Modifier_focus_in_event             (GtkWidget       *widget,
                                        GdkEventFocus   *event,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_retour_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_calcul_clicked              (GtkButton       *button,
                                        gpointer         user_data);
